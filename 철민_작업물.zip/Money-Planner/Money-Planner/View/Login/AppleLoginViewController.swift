//
//  AppleLoginViewController.swift
//  Money-Planner
//
//  Created by 유철민 on 1/6/24.
//

import Foundation
import UIKit

class AppleLoginViewController : UIViewController{
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
