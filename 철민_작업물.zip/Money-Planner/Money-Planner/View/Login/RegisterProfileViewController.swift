//
//  RegisterProfileViewController.swift
//  Money-Planner
//
//  Created by 유철민 on 1/6/24.
//

import Foundation
import UIKit

class RegisterProfileViewController : UIViewController{
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
