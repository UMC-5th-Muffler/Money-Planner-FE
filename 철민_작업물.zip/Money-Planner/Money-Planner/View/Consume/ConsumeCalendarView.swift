//
//  ConsumeCalendarView.swift
//  Money-Planner
//
//  Created by p_kxn_g on 1/22/24.
//

import Foundation
