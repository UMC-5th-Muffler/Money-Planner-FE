//
//  DailyExpenseGoalModal.swift
//  Money-Planner
//
//  Created by 유철민 on 2/18/24.
//

import Foundation
import UIKit

class DailyExpenseGoalModal : UIViewController {
    
    
}
