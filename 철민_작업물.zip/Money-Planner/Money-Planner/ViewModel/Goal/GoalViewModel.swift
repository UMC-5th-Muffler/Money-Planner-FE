//
//  GoalViewModel.swift
//  Money-Planner
//
//  Created by 유철민 on 1/12/24.
//

import Foundation
import Moya
import RxSwift
import RxCocoa

class GoalViewModel {
    
    

}
