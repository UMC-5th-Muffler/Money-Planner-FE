//
//  GoalCategoryViewModel.swift
//  Money-Planner
//
//  Created by 유철민 on 2/17/24.
//

import Foundation

class GoalCategoryViewModel {
    
}
